import express from "express";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";
dotenv.config();
const app = express();
const root = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
app.use(express.json({limit:"2mb"}));
app.use(express.static(path.join(root,"public")));

const crypto = await import("node:crypto");
function makeAccessToken(code) {
  return crypto.createHmac("sha256", process.env.ACCESS_TOKEN_SECRET || "change-this-secret").update(code).digest("hex");
}
function validAccess(req) {
  const code = String(req.headers["x-thamuz-access"] || "");
  const owner = process.env.OWNER_ACCESS_CODE || "";
  const paid = process.env.PAID_ACCESS_CODE || "";
  if (!code || !owner || !paid) return false;
  const safeEq = (a,b) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
  return safeEq(makeAccessToken(code), makeAccessToken(owner)) || safeEq(makeAccessToken(code), makeAccessToken(paid));
}
app.post("/api/access", (req,res) => {
  const code = String(req.body?.code || "");
  const owner = process.env.OWNER_ACCESS_CODE || "";
  const paid = process.env.PAID_ACCESS_CODE || "";
  const safeEq = (a,b) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
  if (!owner || !paid) return res.status(503).json({error:"Эзэмшигчийн болон төлбөртэй эрхийн кодыг .env файлд тохируулна уу."});
  if (safeEq(makeAccessToken(code), makeAccessToken(owner))) return res.json({ok:true,plan:"OWNER PREMIUM",message:"Эзэмшигчийн Premium эрх идэвхтэй."});
  if (safeEq(makeAccessToken(code), makeAccessToken(paid))) return res.json({ok:true,plan:"PREMIUM",message:"Premium эрх идэвхтэй."});
  return res.status(403).json({error:"Эрхийн код буруу байна. Төлбөр төлсний дараа эрхийн код авна уу."});
});
app.get("/api/status",(_req,res)=>res.json({ok:true,configured:Boolean(process.env.OPENAI_API_KEY)}));

app.post("/api/chat",async(req,res)=>{
  try {
    if(!process.env.OPENAI_API_KEY) return res.status(503).json({error:"AI тохируулаагүй байна. Сервер дээр .env файлд OPENAI_API_KEY нэмнэ үү."});
    const {messages,mode} = req.body || {};
    if(!Array.isArray(messages)||!messages.length) return res.status(400).json({error:"Мессеж оруулна уу."});
    const instructions = {
      chat:"You are Thamuz24 Pro, a helpful and accurate assistant. Reply in the user's language.",
      writing:"You are Thamuz24 Pro writing assistant. Draft, edit, and translate text. Reply in the user's language.",
      code:"You are Thamuz24 Pro coding assistant. Provide useful code and explain assumptions. Reply in the user's language."
    };
    const r = await fetch("https://api.openai.com/v1/chat/completions",{
      method:"POST",
      headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`,"Content-Type":"application/json"},
      body:JSON.stringify({model:process.env.CHAT_MODEL||"gpt-4.1-mini",messages:[{role:"system",content:instructions[mode]||instructions.chat},...messages.slice(-24)],temperature:0.7})
    });
    const d=await r.json();
    if(!r.ok) return res.status(r.status).json({error:d?.error?.message||"AI хүсэлт амжилтгүй боллоо."});
    res.json({reply:d.choices?.[0]?.message?.content||"Хариу ирсэнгүй."});
  } catch { res.status(500).json({error:"Серверийн алдаа гарлаа."}); }
});

app.post("/api/image",async(req,res)=>{
  try {
    if(!process.env.OPENAI_API_KEY) return res.status(503).json({error:"AI тохируулаагүй байна. Сервер дээр .env файлд OPENAI_API_KEY нэмнэ үү."});
    const prompt=String(req.body?.prompt||"").trim();
    if(!prompt) return res.status(400).json({error:"Зургийн санаагаа бичнэ үү."});
    if(prompt.length>4000) return res.status(400).json({error:"Зургийн тайлбар хэт урт байна."});
    const r=await fetch("https://api.openai.com/v1/images/generations",{
      method:"POST",
      headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`,"Content-Type":"application/json"},
      body:JSON.stringify({model:process.env.IMAGE_MODEL||"gpt-image-1",prompt,size:"1024x1024"})
    });
    const d=await r.json();
    if(!r.ok) return res.status(r.status).json({error:d?.error?.message||"Зураг үүсгэх хүсэлт амжилтгүй боллоо."});
    const item=d.data?.[0];
    if(item?.b64_json) return res.json({image:`data:image/png;base64,${item.b64_json}`});
    if(item?.url) return res.json({image:item.url});
    res.status(502).json({error:"Зургийн үр дүн ирсэнгүй."});
  } catch { res.status(500).json({error:"Зураг үүсгэх үед серверийн алдаа гарлаа."}); }
});
app.get("*",(_req,res)=>res.sendFile(path.join(root,"public","index.html")));
app.listen(PORT,()=>console.log(`Thamuz24 Pro: http://localhost:${PORT}`));
