const $=id=>document.getElementById(id);let mode="chat",history=[],installPrompt=null,busy=false;
const names={chat:"AI чат",writing:"Бичвэр бичих",code:"Код бичих",image:"AI зураг"};
let accessCode=localStorage.getItem("thamuz24_access_code")||"";
async function ensureAccess(){
  if(accessCode) return true;
  const code=prompt("Thamuz24 Pro Premium эрхийн кодоо оруулна уу. Эзэмшигч өөрийн үнэгүй Premium кодыг ашиглана.");
  if(!code) return false;
  try{
    const r=await fetch("/api/access",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code})});
    const d=await r.json();
    if(!r.ok) throw Error(d.error||"Эрхийн код буруу.");
    accessCode=code;localStorage.setItem("thamuz24_access_code",code);alert(d.message||"Premium идэвхжлээ.");return true;
  }catch(e){alert(e.message);return false}
}
async function status(){try{const r=await fetch("/api/status"),d=await r.json();$("apiStatus").textContent=d.configured?"AI холбогдсон":"API түлхүүр шаардлагатай";$("dot").classList.toggle("ready",d.configured)}catch{$("apiStatus").textContent="Сервертэй холбогдоогүй"}}
function setMode(m){mode=m;document.querySelectorAll(".nav").forEach(b=>b.classList.toggle("active",b.dataset.mode===m));$("modeTitle").textContent=names[m];$("imagePanel").hidden=m!=="image";$("composerWrap").hidden=m==="image";if(m==="image")$("welcome").hidden=true;else if(!history.length)$("welcome").hidden=false;if(innerWidth<761)$("sidebar").classList.remove("open");$("prompt").placeholder=m==="writing"?"Ямар бичвэр бичих вэ?":m==="code"?"Ямар код бичүүлэх вэ?":"Thamuz24 Pro-аас юу асуух вэ?"}
function add(role,text,cls=""){const wrap=document.createElement("div");wrap.className=`message ${role} ${cls}`;const av=document.createElement("div");av.className="avatar";av.textContent=role==="user"?"Чи":"✦";const body=document.createElement("div");body.className="body";body.textContent=text;wrap.append(av,body);$("welcome").hidden=true;$("messages").append(wrap);wrap.scrollIntoView({behavior:"smooth",block:"end"});return body}
async function send(text){if(!text.trim()||busy)return;if(!await ensureAccess())return;busy=true;$("send").disabled=true;add("user",text);history.push({role:"user",content:text});const out=add("assistant","Thamuz24 Pro бодож байна…","typing");try{const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json","x-thamuz-access":accessCode},body:JSON.stringify({messages:history,mode})});const d=await r.json();if(!r.ok)throw Error(d.error||"Хүсэлт амжилтгүй боллоо.");out.textContent=d.reply;out.parentElement.classList.remove("typing");history.push({role:"assistant",content:d.reply})}catch(e){out.textContent=e.message;out.parentElement.classList.add("error")}finally{busy=false;$("send").disabled=false;$("prompt").focus()}}
$("form").addEventListener("submit",e=>{e.preventDefault();const t=$("prompt").value.trim();if(t){$("prompt").value="";send(t)}});$("prompt").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("form").requestSubmit()}});
document.querySelectorAll(".nav").forEach(b=>b.addEventListener("click",()=>setMode(b.dataset.mode)));
$("newChat").addEventListener("click",()=>{history=[];$("messages").replaceChildren();$("welcome").hidden=false;$("imageResult").replaceChildren();$("imagePrompt").value="";setMode("chat")});
document.querySelectorAll(".quick button").forEach(b=>b.addEventListener("click",()=>{setMode(b.dataset.kind);if(b.dataset.kind==="image")$("imagePrompt").value=b.dataset.prompt;else{$("prompt").value=b.dataset.prompt;$("prompt").focus()}}));
$("generate").addEventListener("click",async()=>{const prompt=$("imagePrompt").value.trim();if(!prompt)return;if(!await ensureAccess())return;const btn=$("generate"),result=$("imageResult");btn.disabled=true;btn.textContent="Зураг үүсгэж байна…";result.textContent="Түр хүлээнэ үү…";try{const r=await fetch("/api/image",{method:"POST",headers:{"Content-Type":"application/json","x-thamuz-access":accessCode},body:JSON.stringify({prompt})});const d=await r.json();if(!r.ok)throw Error(d.error||"Зураг үүсгэсэнгүй.");result.replaceChildren();const img=document.createElement("img");img.src=d.image;img.alt="Thamuz24 Pro зураг";result.append(img);const a=document.createElement("a");a.href=d.image;a.download="thamuz24-pro-image.png";a.textContent="↓ Зургийг татах";result.append(a)}catch(e){result.textContent=e.message}finally{btn.disabled=false;btn.textContent="✦ Зураг үүсгэх"}});
$("menu").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
addEventListener("beforeinstallprompt",e=>{e.preventDefault();installPrompt=e;$("install").hidden=false});
$("install").addEventListener("click",async()=>{if(installPrompt){installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;$("install").hidden=true}});
if("serviceWorker"in navigator)addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));status();
