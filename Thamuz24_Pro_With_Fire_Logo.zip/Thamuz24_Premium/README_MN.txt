THAMUZ24 PRO PREMIUM — OWNER FREE / OTHER USERS PAID ACCESS
=========================================================

ЭНЭ БАГЦАД
- Хар + нил ягаан premium PWA загвар
- AI чат, бичвэр, код, зураг
- Android болон PC browser-оос суулгах PWA файлууд
- Premium эрхийн кодын шалгалт
- Эзэмшигчийн OWNER_ACCESS_CODE-оор үнэгүй Premium; бусад хэрэглэгч PAID_ACCESS_CODE-оор нэвтэрнэ

ЧУХАЛ ТОДРУУЛГА
Энэ багц нь эх кодын багц бөгөөд бэлэн APK эсвэл Windows EXE биш. Үүнийг ажиллуулахын тулд Node.js, HTTPS сервер, AI API түлхүүр тохируулна.
Төлбөр автоматаар авах Stripe зэрэг төлбөрийн систем энд холбогдоогүй. Одоогийн хувилбарт төлбөрийг та гадуур хүлээн авч, төлсөн хэрэглэгчдэд PAID_ACCESS_CODE өгөх зарчмаар ажиллана. Нэг ижил PAID_ACCESS_CODE-г олон хүнд тараавал тэд хуваалцаж болно. Бодит арилжааны нээлтэд хэрэглэгчийн бүртгэл, төлбөрийн provider, төлбөрийн webhook, хэрэглэгч тус бүрийн subscription шалгалт нэмж хэрэгтэй.

ТОХИРУУЛАХ
1. Node.js LTS: https://nodejs.org/en/download/
2. ZIP задлаад хавтас дотор Terminal нээнэ.
3. npm install
4. .env.example файлыг .env нэрээр хуулна.
5. .env дотор:
   OPENAI_API_KEY= өөрийн API түлхүүр
   OWNER_ACCESS_CODE= зөвхөн таны мэдэх урт нууц код
   PAID_ACCESS_CODE= төлбөр төлсөн хүмүүст өгөх код
   ACCESS_TOKEN_SECRET= урт, санамсаргүй нууц мөр
6. npm start
7. http://localhost:3000 хаягаар нээнэ.

УТАС / PC-Д СУУЛГАХ
- HTTPS дэмждэг серверт байршуулж URL гаргана.
- Android Chrome: ⋮ > Install app / Add to Home screen.
- Windows/macOS Chrome/Edge: Install товч/дүрс.
- PWA суулгахад HTTPS шаардлагатай (localhost хөгжүүлэлтэд онцгой).

АЮУЛГҮЙ БАЙДАЛ
- .env-ээ хэзээ ч public repo-д бүү оруул.
- OWNER_ACCESS_CODE, PAID_ACCESS_CODE, ACCESS_TOKEN_SECRET-г бусдад бүү өг.
- Кодын эрхийн горим нь эхний хувилбар; өндөр хэрэглээтэй олон нийтийн үйлчилгээ болгохын өмнө account database, rate limiting, per-user billing, logging, privacy policy нэмж хэрэгтэй.
- AI ашиглалт нь API account / billing-ээс хамаарч төлбөртэй байж болно.


ТӨЛБӨРИЙН ТУХАЙ:
- Таны OWNER_ACCESS_CODE нь таны Premium эрхийг үнэгүй идэвхжүүлнэ.
- Бусад хэрэглэгч PAID_ACCESS_CODE ашиглаж нэвтэрнэ. Энэ эхний хувилбарт автомат төлбөрийн систем холбогдоогүй тул төлбөрийг та өөрөө шалгаж, кодоо гараар өгнө.
- PAID_ACCESS_CODE-ийг нийтэд ил тавьж болохгүй; нэг кодыг олон хүн хуваалцвал төлбөрийн хамгаалалт сул болно.
- AI API хэрэглээ төлбөртэй байж болно.
